// import FlipCard from "@/components/FlipCard";

export default async function Detail({ params }) {

    const { pokemonId } = params;

    const res = await fetch(`http://localhost:3000/api/pokemon/${pokemonId}`, {
        method: "GET",
        cache: "no-store",
    });

    if (!res.ok) {
        throw new Error("포켓몬 정보를 불러오지 못했습니다.");
    }

    const { pokemonData } = await res.json();

    return (
        <div className="bg-white flex flex-col justify-center items-center border py-[30px] px-[60px] rounded-[10px] border-b-[8px] border-r-[8px] border-black">
            <div className="text-[24px] mb-[10px]">
                {pokemonData.name}
                {/* <FavoriteButton pokemonId={Number(pokemonId)} /> */}
            </div>
            <div className="whitespace-pre-wrap text-center">{pokemonData.description}</div>
            {/* <img className="w-[200px]" src={pokemon.front} /> */}
            {/* <FlipCard front={pokepokemonDatamon.front} back={pokemonData.back} /> */}
        </div>
    )
}